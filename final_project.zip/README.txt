Othello Prolog.

Hexanôme 4411 :
    - BRANCHEREAU Corentin
    - CACHARD Sylvain
    - GRAVEY Thibaut
    - DE ANDRIA Quentin
    - ROB Louis
    - MIGNOT Thomas
    - OECHSLIN Killian

Instructions pour le lancement :
    
    * Version sans IHM :
        
        -> Algorithme Alpha-Bêta :
            - Aller dans le dossier 'console'
            - Lancer Prolog
            - Charger le fichier 'squelette.pl' => ?- [squelette].
            - Lancer l'othello => ?- init.
        
        -> Algorithme IDS :
            - Aller dans le dossier 'console'
            - Lancer Prolog
            - Charger le fichier 'squelette_ids.pl' => ?- [squelette_ids].
            - Lancer l'othello => ?- init.

    * Version avec IHM (nécessite la librairie XPCE):

    *** NOTE : l'IHM est plus adaptée sur Linux. Il est donc préférable de lancer la version IHM à partir d'une distribution Linux

        - Aller dans le dossier 'ihm'
        - Lancer Prolog
        - Charger le fichier 'squelette.pl' => ?- [squelette].
        - Lancer l'othello => ?- init.